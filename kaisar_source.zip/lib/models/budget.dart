class Budget {
  final int? id;
  final String category;
  final int limitAmount;
  const Budget({this.id, required this.category, required this.limitAmount});
  Map<String, Object?> toMap() => {'id': id, 'category': category, 'limit_amount': limitAmount};
  factory Budget.fromMap(Map<String, Object?> m) => Budget(
    id: m['id'] as int?, category: m['category'] as String, limitAmount: m['limit_amount'] as int);
}

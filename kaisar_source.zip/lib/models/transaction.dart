class FinanceTransaction {
  final int? id;
  final String type; // income, expense, transfer
  final int amount;
  final String category;
  final String wallet;
  final String date; // ISO-8601
  final String note;

  const FinanceTransaction({this.id, required this.type, required this.amount,
    required this.category, required this.wallet, required this.date, this.note = ''});

  Map<String, Object?> toMap() => {
    'id': id, 'type': type, 'amount': amount, 'category': category,
    'wallet': wallet, 'date': date, 'note': note,
  };

  factory FinanceTransaction.fromMap(Map<String, Object?> map) => FinanceTransaction(
    id: map['id'] as int?, type: map['type'] as String,
    amount: map['amount'] as int, category: map['category'] as String,
    wallet: map['wallet'] as String, date: map['date'] as String,
    note: (map['note'] as String?) ?? '',
  );
}

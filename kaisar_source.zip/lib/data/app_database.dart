import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/transaction.dart';
import '../models/budget.dart';

class AppDatabase {
  static Database? _db;
  Future<void> initialize() async {
    if (_db != null) return;
    final dbPath = join(await getDatabasesPath(), 'kaisar_finance.db');
    _db = await openDatabase(dbPath, version: 1, onCreate: (db, version) async {
      await db.execute('''CREATE TABLE transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, amount INTEGER NOT NULL,
        category TEXT NOT NULL, wallet TEXT NOT NULL, date TEXT NOT NULL, note TEXT NOT NULL)''');
      await db.execute('''CREATE TABLE budgets(
        id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL UNIQUE, limit_amount INTEGER NOT NULL)''');
      await db.execute('''CREATE TABLE wallets(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, opening_balance INTEGER NOT NULL DEFAULT 0)''');
      await db.execute('''CREATE TABLE goals(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, target INTEGER NOT NULL, saved INTEGER NOT NULL DEFAULT 0)''');
      final now = DateTime.now();
      final samples = [
        ['income', 8500000, 'Gaji', 'BCA', DateTime(now.year, now.month, 1).toIso8601String(), 'Gaji bulanan'],
        ['expense', 45000, 'Makanan', 'Tunai', now.subtract(const Duration(days: 1)).toIso8601String(), 'Makan siang'],
        ['expense', 75000, 'Transportasi', 'GoPay', now.subtract(const Duration(days: 2)).toIso8601String(), 'Bensin'],
        ['expense', 250000, 'Tagihan', 'BCA', now.subtract(const Duration(days: 3)).toIso8601String(), 'Internet'],
        ['expense', 120000, 'Hiburan', 'OVO', now.subtract(const Duration(days: 4)).toIso8601String(), 'Nonton'],
      ];
      final batch = db.batch();
      for (final s in samples) {
        batch.insert('transactions', {'type':s[0], 'amount':s[1], 'category':s[2], 'wallet':s[3], 'date':s[4], 'note':s[5]});
      }
      for (final w in ['Tunai','BCA','Mandiri','GoPay','OVO']) {
        batch.insert('wallets', {'name':w,'opening_balance':0});
      }
      for (final b in [['Makanan',1500000],['Transportasi',600000],['Tagihan',1000000],['Hiburan',500000]]) {
        batch.insert('budgets', {'category':b[0], 'limit_amount':b[1]});
      }
      batch.insert('goals', {'name':'Dana Darurat','target':10000000,'saved':2500000});
      await batch.commit();
    });
  }
  Database get db => _db!;
  Future<List<FinanceTransaction>> transactions() async =>
    (await db.query('transactions', orderBy:'date DESC')).map(FinanceTransaction.fromMap).toList();
  Future<int> addTransaction(FinanceTransaction t) => db.insert('transactions', t.toMap());
  Future<int> updateTransaction(FinanceTransaction t) => db.update('transactions', t.toMap(), where:'id=?', whereArgs:[t.id]);
  Future<int> deleteTransaction(int id) => db.delete('transactions', where:'id=?', whereArgs:[id]);
  Future<List<Budget>> budgets() async => (await db.query('budgets')).map(Budget.fromMap).toList();
  Future<void> saveBudget(Budget b) async => db.insert('budgets', b.toMap(),
    conflictAlgorithm: ConflictAlgorithm.replace);
  Future<List<Map<String,Object?>>> wallets() => db.query('wallets', orderBy:'name');
  Future<List<Map<String,Object?>>> goals() => db.query('goals', orderBy:'id DESC');
}

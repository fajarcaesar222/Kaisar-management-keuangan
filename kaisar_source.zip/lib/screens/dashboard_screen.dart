import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../state/finance_state.dart';
import '../utils/format.dart';
import 'transaction_form_screen.dart';
import 'transactions_screen.dart';

const navy=Color(0xFF0F172A), gold=Color(0xFFF59E0B), green=Color(0xFF10B981), red=Color(0xFFEF4444);

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});
  @override Widget build(BuildContext context) {
    final s=context.watch<FinanceState>();
    return s.loading ? const Center(child:CircularProgressIndicator()) : RefreshIndicator(
      onRefresh:s.load, child:ListView(padding:const EdgeInsets.fromLTRB(20,18,20,100),children:[
        Row(children:[Container(padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:gold,borderRadius:BorderRadius.circular(14)),child:const Icon(Icons.workspace_premium,color:navy)),
          const SizedBox(width:10),const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('KAISAR',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:2,color:navy,fontSize:18)),Text('Management Keuangan',style:TextStyle(color:Colors.blueGrey,fontSize:12))]),
          const Spacer(),IconButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Data tersimpan offline di perangkat ini.'))),icon:const Icon(Icons.notifications_none))]),
        const SizedBox(height:22),
        Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(gradient:const LinearGradient(colors:[navy,Color(0xFF1E3A5F)]),borderRadius:BorderRadius.circular(24),boxShadow:[BoxShadow(color:navy.withOpacity(.14),blurRadius:20,offset:const Offset(0,8))]),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('TOTAL SALDO',style:TextStyle(color:Color(0xFFCBD5E1),letterSpacing:1.5,fontSize:11)),
          const SizedBox(height:8),Text(rupiah(s.balance),style:const TextStyle(color:Colors.white,fontWeight:FontWeight.bold,fontSize:28)),
          const SizedBox(height:20),Row(children:[_miniBalance('Pemasukan',s.monthIncome,green,Icons.south_west),const SizedBox(width:20),_miniBalance('Pengeluaran',s.monthExpense,red,Icons.north_east)])
        ])),
        const SizedBox(height:22),
        Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Ringkasan bulan ini',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold,color:navy)),Text(DateTime.now().month.toString()+'/'+DateTime.now().year.toString(),style:const TextStyle(color:Colors.blueGrey))]),
        const SizedBox(height:12),
        Row(children:[Expanded(child:_stat('Pemasukan',s.monthIncome,green,Icons.trending_up)),const SizedBox(width:12),Expanded(child:_stat('Pengeluaran',s.monthExpense,red,Icons.trending_down))]),
        const SizedBox(height:22),
        Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('Komposisi Pengeluaran',style:TextStyle(fontWeight:FontWeight.bold,fontSize:16,color:navy)),
          const SizedBox(height:12),SizedBox(height:175,child:Row(children:[
            Expanded(child:PieChart(PieChartData(centerSpaceRadius:42,sectionsSpace:3,sections:[
              PieChartSectionData(value:(s.monthExpense==0?1:s.transactions.where((t)=>t.type=='expense'&&t.category=='Makanan').fold<int>(0,(a,t)=>a+t.amount)).toDouble(),color:gold,radius:48,showTitle:false),
              PieChartSectionData(value:s.transactions.where((t)=>t.type=='expense'&&t.category=='Transportasi').fold<int>(0,(a,t)=>a+t.amount).toDouble()+1,color:green,radius:48,showTitle:false),
              PieChartSectionData(value:s.transactions.where((t)=>t.type=='expense'&&t.category!='Makanan'&&t.category!='Transportasi').fold<int>(0,(a,t)=>a+t.amount).toDouble()+1,color:const Color(0xFF64748B),radius:48,showTitle:false),
            ]))),
            const Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.start,children:[
              _Legend(color:gold,label:'Makanan'),SizedBox(height:9),_Legend(color:green,label:'Transportasi'),SizedBox(height:9),_Legend(color:Color(0xFF64748B),label:'Lainnya')])
          ]))
        ]))),
        const SizedBox(height:22),
        Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Transaksi Terakhir',style:TextStyle(fontWeight:FontWeight.bold,fontSize:17,color:navy)),TextButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const TransactionListPage())),child:const Text('Lihat Semua'))]),
        ...s.transactions.take(5).map((t)=>_transactionTile(context,t)),
        const SizedBox(height:12),
        SizedBox(height:50,child:FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:gold,foregroundColor:navy),onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const TransactionFormScreen())),icon:const Icon(Icons.add),label:const Text('Tambah Transaksi',style:TextStyle(fontWeight:FontWeight.bold))))
      ]));
  }
  Widget _miniBalance(String label,int amount,Color color,IconData icon)=>Expanded(child:Row(children:[Icon(icon,color:color,size:17),const SizedBox(width:6),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:const TextStyle(color:Color(0xFFCBD5E1),fontSize:11)),Text(rupiah(amount),maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(color:color,fontWeight:FontWeight.bold,fontSize:13))]))]));
  Widget _stat(String title,int amount,Color color,IconData icon)=>Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:color),const SizedBox(height:9),Text(title,style:const TextStyle(color:Colors.blueGrey,fontSize:12)),const SizedBox(height:4),Text(rupiah(amount),style:const TextStyle(fontWeight:FontWeight.bold,color:navy,fontSize:15))])));
  Widget _transactionTile(BuildContext context,t)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:(t.type=='income'?green:red).withOpacity(.12),child:Icon(t.type=='income'?Icons.south_west:Icons.north_east,color:t.type=='income'?green:red)),title:Text(t.category,style:const TextStyle(fontWeight:FontWeight.w600)),subtitle:Text('${t.wallet} • ${shortDate(t.date)}'),trailing:Text('${t.type=='income'?'+':'-'} ${rupiah(t.amount)}',style:TextStyle(color:t.type=='income'?green:red,fontWeight:FontWeight.bold,fontSize:12)))));
}
class _Legend extends StatelessWidget {final Color color;final String label;const _Legend({required this.color,required this.label});@override Widget build(BuildContext c)=>Row(children:[CircleAvatar(radius:5,backgroundColor:color),const SizedBox(width:7),Text(label,style:const TextStyle(fontSize:12))]);}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/finance_state.dart';
import '../utils/format.dart';

class WalletsScreen extends StatelessWidget {
 const WalletsScreen({super.key});
 @override Widget build(BuildContext context){final s=context.watch<FinanceState>();return Scaffold(appBar:AppBar(title:const Text('Dompet & Rekening')),body:ListView(padding:const EdgeInsets.all(18),children:[
  const Text('Pisahkan sumber dana agar lebih mudah dipantau.',style:TextStyle(color:Colors.blueGrey)),const SizedBox(height:16),
  ...s.wallets.map((w){final name=w['name'] as String;final income=s.transactions.where((t)=>t.wallet==name&&t.type=='income').fold<int>(0,(a,t)=>a+t.amount);final expense=s.transactions.where((t)=>t.wallet==name&&t.type=='expense').fold<int>(0,(a,t)=>a+t.amount);return Card(child:ListTile(leading:CircleAvatar(backgroundColor:const Color(0xFFFFF3D6),child:Icon(name=='Tunai'?Icons.payments_outlined:Icons.account_balance,color:const Color(0xFFB7791F))),title:Text(name,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('Masuk ${rupiah(income)} • Keluar ${rupiah(expense)}'),trailing:Text(rupiah(income-expense),style:const TextStyle(fontWeight:FontWeight.bold))));})
 ]));}
}

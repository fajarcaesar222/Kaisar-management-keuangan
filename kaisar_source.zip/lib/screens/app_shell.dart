import 'package:flutter/material.dart';
import 'dashboard_screen.dart';
import 'transactions_screen.dart';
import 'budgets_screen.dart';
import 'wallets_screen.dart';
import 'transaction_form_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override State<AppShell> createState()=>_AppShellState();
}
class _AppShellState extends State<AppShell> {
  int index=0;
  final pages=const [DashboardScreen(),TransactionsScreen(),BudgetsScreen(),WalletsScreen()];
  @override Widget build(BuildContext context)=>Scaffold(
    body: SafeArea(child: IndexedStack(index:index,children:pages)),
    floatingActionButton: index==1 ? FloatingActionButton.extended(
      backgroundColor: const Color(0xFFF59E0B), foregroundColor: const Color(0xFF0F172A),
      onPressed: ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const TransactionFormScreen())),
      icon: const Icon(Icons.add), label: const Text('Transaksi')) : null,
    bottomNavigationBar: NavigationBar(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),
      destinations: const [
        NavigationDestination(icon:Icon(Icons.grid_view_rounded),label:'Beranda'),
        NavigationDestination(icon:Icon(Icons.receipt_long_rounded),label:'Transaksi'),
        NavigationDestination(icon:Icon(Icons.pie_chart_outline),label:'Anggaran'),
        NavigationDestination(icon:Icon(Icons.account_balance_wallet_outlined),label:'Dompet'),
      ]),
  );
}

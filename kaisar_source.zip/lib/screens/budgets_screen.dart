import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/budget.dart';
import '../state/finance_state.dart';
import '../utils/format.dart';

class BudgetsScreen extends StatelessWidget {
 const BudgetsScreen({super.key});
 @override Widget build(BuildContext context){final s=context.watch<FinanceState>();return Scaffold(appBar:AppBar(title:const Text('Manajemen Anggaran')),floatingActionButton:FloatingActionButton.extended(backgroundColor:const Color(0xFFF59E0B),foregroundColor:const Color(0xFF0F172A),onPressed:()=>_addBudget(context),icon:const Icon(Icons.add),label:const Text('Anggaran')),body:ListView(padding:const EdgeInsets.all(18),children:[
  const Text('Kontrol pengeluaran bulanan berdasarkan kategori.',style:TextStyle(color:Colors.blueGrey)),const SizedBox(height:18),
  ...s.budgets.map((b){final spent=s.spentFor(b.category);final ratio=b.limitAmount==0?0:spent/b.limitAmount;final color=ratio>=1?Colors.red:ratio>=.8?Colors.orange:Colors.green;return Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
   Row(children:[Expanded(child:Text(b.category,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16))),Text('${(ratio*100).round()}%',style:TextStyle(color:color,fontWeight:FontWeight.bold))]),
   const SizedBox(height:12),ClipRRect(borderRadius:BorderRadius.circular(20),child:LinearProgressIndicator(value:ratio.clamp(0,1).toDouble(),minHeight:10,backgroundColor:const Color(0xFFE2E8F0),color:color)),
   const SizedBox(height:10),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text('Terpakai: ${rupiah(spent)}',style:const TextStyle(fontSize:12)),Text('Batas: ${rupiah(b.limitAmount)}',style:const TextStyle(fontSize:12,color:Colors.blueGrey))]),
   if(ratio>=1)const Padding(padding:EdgeInsets.only(top:8),child:Text('Anggaran terlampaui!',style:TextStyle(color:Colors.red,fontWeight:FontWeight.w600)))
  ])));})
 ]));}
 Future<void> _addBudget(BuildContext context) async {final c=TextEditingController();String category='Makanan';final cats=['Makanan','Transportasi','Tagihan','Hiburan','Belanja','Kesehatan','Lainnya'];await showDialog(context:context,builder:(d)=>AlertDialog(title:const Text('Atur Anggaran'),content:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField(value:category,items:cats.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>category=v!),const SizedBox(height:12),TextField(controller:c,keyboardType:TextInputType.number,decoration:const InputDecoration(prefixText:'Rp ',hintText:'Batas anggaran'))]),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('Batal')),FilledButton(onPressed:()async{final n=int.tryParse(c.text.replaceAll('.',''));if(n!=null&&n>0)await context.read<FinanceState>().saveBudget(Budget(category:category,limitAmount:n));if(d.mounted)Navigator.pop(d);},child:const Text('Simpan'))]));}
}

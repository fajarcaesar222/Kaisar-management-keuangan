import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/transaction.dart';
import '../state/finance_state.dart';

class TransactionFormScreen extends StatefulWidget {
  const TransactionFormScreen({super.key});
  @override State<TransactionFormScreen> createState()=>_TransactionFormScreenState();
}
class _TransactionFormScreenState extends State<TransactionFormScreen> {
  final form=GlobalKey<FormState>(); final amount=TextEditingController(); final note=TextEditingController();
  String type='expense',category='Makanan',wallet='Tunai'; DateTime date=DateTime.now();
  final categories=['Makanan','Transportasi','Tagihan','Gaji','Investasi','Hiburan','Belanja','Kesehatan','Lainnya'];
  final wallets=['Tunai','BCA','Mandiri','GoPay','OVO'];
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Tambah Transaksi')),body:Form(key:form,child:ListView(padding:const EdgeInsets.all(20),children:[
    SegmentedButton<String>(segments:const [ButtonSegment(value:'income',label:Text('Pemasukan'),icon:Icon(Icons.add)),ButtonSegment(value:'expense',label:Text('Pengeluaran'),icon:Icon(Icons.remove)),ButtonSegment(value:'transfer',label:Text('Transfer'),icon:Icon(Icons.swap_horiz))],selected:{type},onSelectionChanged:(v)=>setState(()=>type=v.first)),
    const SizedBox(height:20),const Text('Nominal (IDR)'),const SizedBox(height:8),
    TextFormField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(prefixText:'Rp ',hintText:'Contoh: 50000'),validator:(v)=>int.tryParse((v??'').replaceAll('.','').replaceAll(',',''))==null?'Masukkan nominal yang valid':null),
    const SizedBox(height:16),const Text('Kategori'),const SizedBox(height:8),
    DropdownButtonFormField(value:category,items:categories.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>category=v!)),
    const SizedBox(height:16),const Text('Dompet / Metode Pembayaran'),const SizedBox(height:8),
    DropdownButtonFormField(value:wallet,items:wallets.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>wallet=v!)),
    const SizedBox(height:16),const Text('Tanggal'),const SizedBox(height:8),
    OutlinedButton.icon(onPressed:()async{final d=await showDatePicker(context:context,initialDate:date,firstDate:DateTime(2020),lastDate:DateTime(2100));if(d!=null)setState(()=>date=d);},icon:const Icon(Icons.calendar_month),label:Text('${date.day}/${date.month}/${date.year}')),
    const SizedBox(height:16),const Text('Catatan'),const SizedBox(height:8),TextFormField(controller:note,maxLines:3,decoration:const InputDecoration(hintText:'Tambahkan keterangan (opsional)')),
    const SizedBox(height:28),FilledButton(style:FilledButton.styleFrom(backgroundColor:const Color(0xFF0F172A),padding:const EdgeInsets.all(16)),onPressed:()async{if(!form.currentState!.validate())return;final raw=amount.text.replaceAll('.','').replaceAll(',','');await context.read<FinanceState>().saveTransaction(FinanceTransaction(type:type,amount:int.parse(raw),category:category,wallet:wallet,date:date.toIso8601String(),note:note.text));if(context.mounted)Navigator.pop(context);},child:const Text('Simpan Transaksi'))
  ])));
  @override void dispose(){amount.dispose();note.dispose();super.dispose();}
}

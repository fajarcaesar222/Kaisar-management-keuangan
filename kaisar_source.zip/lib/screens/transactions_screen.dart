import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/finance_state.dart';
import '../utils/format.dart';
import 'transaction_form_screen.dart';

class TransactionsScreen extends StatelessWidget {
 const TransactionsScreen({super.key});
 @override Widget build(BuildContext context)=>const TransactionListPage();
}
class TransactionListPage extends StatelessWidget {
 const TransactionListPage({super.key});
 @override Widget build(BuildContext context){final s=context.watch<FinanceState>();return Scaffold(appBar:AppBar(title:const Text('Riwayat Transaksi')),body:ListView(padding:const EdgeInsets.all(16),children:[
  FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const TransactionFormScreen())),icon:const Icon(Icons.add),label:const Text('Tambah transaksi')),
  const SizedBox(height:12),...s.transactions.map((t)=>Card(child:ListTile(leading:Icon(t.type=='income'?Icons.south_west:Icons.north_east,color:t.type=='income'?Colors.green:Colors.red),title:Text(t.category),subtitle:Text('${t.wallet} • ${shortDate(t.date)}'),trailing:Row(mainAxisSize:MainAxisSize.min,children:[Text(rupiah(t.amount)),IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>showDialog(context:context,builder:(d)=>AlertDialog(title:const Text('Hapus transaksi?'),content:const Text('Data transaksi ini akan dihapus.'),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('Batal')),TextButton(onPressed:(){s.removeTransaction(t.id!);Navigator.pop(d);},child:const Text('Hapus'))])))]))))
 ]));}
}

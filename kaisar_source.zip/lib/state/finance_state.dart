import 'package:flutter/foundation.dart';
import '../data/app_database.dart';
import '../models/transaction.dart';
import '../models/budget.dart';

class FinanceState extends ChangeNotifier {
  final AppDatabase db;
  FinanceState(this.db);
  List<FinanceTransaction> transactions = [];
  List<Budget> budgets = [];
  List<Map<String,Object?>> wallets = [];
  List<Map<String,Object?>> goals = [];
  bool loading = true;

  Future<void> load() async {
    loading = true; notifyListeners();
    transactions = await db.transactions();
    budgets = await db.budgets();
    wallets = await db.wallets();
    goals = await db.goals();
    loading = false; notifyListeners();
  }
  Future<void> saveTransaction(FinanceTransaction t) async {
    if (t.id == null) { await db.addTransaction(t); } else { await db.updateTransaction(t); }
    await load();
  }
  Future<void> removeTransaction(int id) async { await db.deleteTransaction(id); await load(); }
  Future<void> saveBudget(Budget b) async { await db.saveBudget(b); await load(); }

  int get totalIncome => transactions.where((t)=>t.type=='income').fold(0,(s,t)=>s+t.amount);
  int get totalExpense => transactions.where((t)=>t.type=='expense').fold(0,(s,t)=>s+t.amount);
  int get balance => totalIncome-totalExpense;
  int get monthIncome => _monthTotal('income');
  int get monthExpense => _monthTotal('expense');
  int _monthTotal(String type) {
    final now=DateTime.now();
    return transactions.where((t) {
      final d=DateTime.tryParse(t.date);
      return t.type==type && d!=null && d.year==now.year && d.month==now.month;
    }).fold(0,(s,t)=>s+t.amount);
  }
  int spentFor(String category) {
    final now=DateTime.now();
    return transactions.where((t) {
      final d=DateTime.tryParse(t.date);
      return t.type=='expense' && t.category==category && d!=null && d.year==now.year && d.month==now.month;
    }).fold(0,(s,t)=>s+t.amount);
  }
}

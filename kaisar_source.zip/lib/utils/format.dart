import 'package:intl/intl.dart';
String rupiah(num value) => NumberFormat.currency(locale:'id_ID', symbol:'Rp ', decimalDigits:0).format(value);
String shortDate(String iso) => DateFormat('dd MMM yyyy','id_ID').format(DateTime.parse(iso));

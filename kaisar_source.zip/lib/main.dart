import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'data/app_database.dart';
import 'state/finance_state.dart';
import 'screens/app_shell.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final db = AppDatabase();
  await db.initialize();
  runApp(ChangeNotifierProvider(
    create: (_) => FinanceState(db)..load(),
    child: const KaisarApp(),
  ));
}

class KaisarApp extends StatelessWidget {
  const KaisarApp({super.key});

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF0F172A);
    const gold = Color(0xFFF59E0B);
    return MaterialApp(
      title: 'Kaisar Management Keuangan',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: navy, brightness: Brightness.light)
            .copyWith(primary: navy, secondary: gold, surface: const Color(0xFFF8FAFC)),
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        fontFamily: 'Inter',
        cardTheme: CardTheme(
          elevation: 0,
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          margin: EdgeInsets.zero,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: const Color(0xFFF1F5F9),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true, brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: navy, brightness: Brightness.dark).copyWith(secondary: gold),
      ),
      themeMode: ThemeMode.system,
      home: const AppShell(),
    );
  }
}

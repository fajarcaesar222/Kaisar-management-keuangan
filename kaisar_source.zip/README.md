# Kaisar Management Keuangan

Aplikasi manajemen keuangan pribadi Android berbasis Flutter + SQLite (offline-first).

## Fitur yang tersedia
- Dashboard saldo, pemasukan/pengeluaran bulan ini, diagram kategori, transaksi terakhir.
- Tambah transaksi pemasukan, pengeluaran, dan transfer (jenis transfer dicatat sebagai tipe transaksi).
- Riwayat transaksi dan hapus transaksi.
- Anggaran per kategori dengan progress bar hijau/kuning/merah.
- Daftar dompet/rekening: Tunai, BCA, Mandiri, GoPay, OVO.
- Data contoh otomatis dibuat saat database pertama kali dibuat.
- Tema terang dan dark mode mengikuti pengaturan perangkat.

## Persiapan
1. Install Flutter SDK dan Android Studio.
2. Pastikan Android SDK dan emulator/perangkat Android sudah siap.
3. Ekstrak folder proyek ini.
4. Jalankan:
   ```bash
   flutter doctor
   flutter pub get
   flutter run
   ```

## Build APK
Untuk APK release:
```bash
flutter build apk --release
```
Hasil biasanya berada di:
`build/app/outputs/flutter-apk/app-release.apk`

Untuk APK debug:
```bash
flutter build apk --debug
```

## Struktur folder
```text
lib/
  main.dart
  data/app_database.dart
  models/transaction.dart
  models/budget.dart
  state/finance_state.dart
  utils/format.dart
  screens/
    app_shell.dart
    dashboard_screen.dart
    transaction_form_screen.dart
    transactions_screen.dart
    budgets_screen.dart
    wallets_screen.dart
```

## Catatan pengembangan
- Database lokal SQLite berada di penyimpanan aplikasi Android.
- Saldo saat ini dihitung dari transaksi pemasukan dikurangi pengeluaran.
- Implementasi transfer antar-dompet, edit transaksi, target tabungan, serta ekspor CSV/PDF masih merupakan tahap pengembangan berikutnya. Dependensi CSV dan PDF sudah disiapkan di pubspec agar mudah ditambahkan.
- Sebelum dipakai untuk pencatatan keuangan penting, lakukan pengujian, backup, dan validasi perhitungan.
- Untuk integrasi Firebase/Supabase di masa depan, pisahkan implementasi repository dari UI dan pertahankan model data.
